package game;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Bird {
    //图片
    BufferedImage image;
    //位置
    int x, y;
    //宽高
    int weight, height;
    //大小，方便计算是否碰撞柱子
    int size;

    //重力加速度
    double g;
    //位移的间隔时间
    double t;
    //最初向上抛速度
    double v0;
    //当前向上抛速度
    double speed;
    //经过时间t之后的位移
    double s;
    //小鸟的倾斜度
    double alpha;

    //一组图片，记录小鸟的动画帧
    BufferedImage[] images;
    //动画数组下标
    int index;

    //初始化小鸟

    public Bird() throws IOException {
        image = ImageIO.read(getClass().getResource("/resources/0.png"));
        weight = image.getWidth();
        height = image.getHeight();
        x = 132;
        y = 280;
        size = 40;

        //初始化位移参数
        g = 4;
        v0 = 20;
        speed = 0;
        t = 0.25;
        s = 0;
        alpha = 0;

        //初始化动画帧的参数
        images = new BufferedImage[8];
        for (int i = 0; i < images.length; i++) {
            images[i] = ImageIO.read(getClass().getResource("/resources/" + i + ".png"));
        }
        index = 0;
    }

    //飞行动作(变化一帧)
    public void fly() {
        index++;
        image = images[(index / 12) % 8];
    }

    //移动一步
    public void step() {
        double v0 = speed;
        //计算向上抛的位移距离（物理公式hhhh）
        s = v0 * t + g * t * t / 2;
        //计算鸟的坐标
        y = y - (int) s;
        //计算下一次移动速度(依然是物理公式hhh)
        double v = v0 - g * t;
        speed = v;
        // 计算倾角（反正切函数）
        alpha = Math.atan(s / 8);
    }

    //向上飞行
    public void flappy() {
        //重置速度
        speed = v0;
    }

    //检查小鸟是否碰到地面
    public boolean hit(Ground ground) {
        boolean hit = y + size / 2 > ground.y;
        if (hit) {
            y = ground.y - size / 2;
            alpha = -3.14159265358979323 / 2;
        }
        return hit;
    }

    //检查小鸟是否碰到柱子
    public boolean hit(Column column) {
        //先检查柱子范围
        if (x > column.x - column.weight / 2 - size / 2
                && x < column.x + column.weight / 2 + size / 2) {
            //再检查是否在柱子间隙中
            if (y > column.y - column.gap / 2 + size / 2 && y < column.y + column.gap / 2 - size / 2) {
                return false;
            }
            return true;
        }
        return false;
    }
}
